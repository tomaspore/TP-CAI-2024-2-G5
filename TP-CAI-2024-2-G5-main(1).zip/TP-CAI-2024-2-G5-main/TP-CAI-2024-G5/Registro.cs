﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_CAI_2024_G5
{
    //Después de loguearse se puede registrar un nuevo tipo de usuario SOLO para los administradores. Los supervisores/vendedores acceden a otra ventana.
    public partial class FrmRegistro : Form
    {
        public FrmRegistro()
        {
            InitializeComponent();
        }

    }
}
